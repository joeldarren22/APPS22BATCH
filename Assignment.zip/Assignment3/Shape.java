public abstract class  Shape
{
  abstract float area();
}