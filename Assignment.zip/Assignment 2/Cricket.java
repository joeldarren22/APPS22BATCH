public abstract class Cricket 
{

}
