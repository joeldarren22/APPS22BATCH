public class Batsman 
{

}
