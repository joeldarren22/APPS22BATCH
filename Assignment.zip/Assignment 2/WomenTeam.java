public class WomenTeam extends Cricket
{
	Bowler bl=new Bowler();
	Batsman bt=new Batsman();
	AllRounder all=new AllRounder();
	WicketKeeper wk=new WicketKeeper();
}
