public class THBS_pvt_ltd 
{
WomenTeam wt=new WomenTeam();
MenTeam mt=new MenTeam();
}
