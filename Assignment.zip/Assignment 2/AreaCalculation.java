public class AreaCalculation 
{

}
