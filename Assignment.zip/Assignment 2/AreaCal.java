public abstract class AreaCal<T extends Number>
{
abstract void square(T length);
abstract void circle(T radius);
abstract void triangle(T base,T height);

}
